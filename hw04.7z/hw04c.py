with open ("text.txt","r+") as f:
    f.write ("hello world")
    if f == f.closed:
        f.close()
print f.closed
