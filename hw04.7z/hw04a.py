apple = ['seeds', 'peel', 'pulp']
for i in apple:
    if i == 'seeds':
        print "Throw away"
    else:
        print 'You can eat it'
